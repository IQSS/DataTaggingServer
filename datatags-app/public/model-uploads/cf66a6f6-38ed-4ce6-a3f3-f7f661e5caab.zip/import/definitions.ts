Base: consists of Cats, Dogs, Rice.

Cats: some of Tom, Shmil, Mitzi.

Dogs[A friendly mamle with a tail]: some of
  Rex ["King", in Latin],
  Pluto [This dog user to be a star, then a planet, now a big rock.],
  Lassie [Eventually comes home.].

Rice: one of White, Full.
