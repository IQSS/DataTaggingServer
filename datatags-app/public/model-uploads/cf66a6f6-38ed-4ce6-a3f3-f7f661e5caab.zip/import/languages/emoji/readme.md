# Sample Model 😎 with Imports 🛬
### Example of how to 🥊 a large decision graph 🐘 to a few 🐤🐤🐤

__Version 0.4__

This is an attempt to use emojis (😻😹), to validate proper unicode handling.
