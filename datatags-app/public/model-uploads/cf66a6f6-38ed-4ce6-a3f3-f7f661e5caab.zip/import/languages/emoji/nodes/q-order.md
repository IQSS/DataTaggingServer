Do the 🐶 s first?
