## Little 😿 is scared of ☠️!

*VETERINARIAN EXAM IS MANDATORY*. Please re-consider your answer.
