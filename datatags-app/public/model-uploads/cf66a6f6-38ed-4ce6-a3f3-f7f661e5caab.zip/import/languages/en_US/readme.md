# Sample Model with Imports
### Example of how to break a large decision graph to a few files

__Version 0.4__

This is a markdown readme file. It can have [Links](http://datatags.org), and also tables:

| Section  | User  | Change |
|------|---------------|-----------|
| 1.1  | John Doe    | Updated       |
| 1.2  | Jane Doe     | Initial version   |
| 4.5  | Lauren Ipsum       |  Incorporated references from @joe   |
| 4.5b  | Ford Prefect |    Removing panic   |
