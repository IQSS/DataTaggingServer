# Base
<-- TODO: describe Base

# Base/Dogs
A friendly mammal with a tail

# Base/Dogs/Rex
"King", in Latin

# Base/Dogs/Pluto
This dog user to be a star, then a planet, now a big rock.

# Base/Dogs/Lassie
Eventually comes home.

# Base/Cats
<-- TODO: describe Base/Cats

# Base/Cats/Tom
<-- TODO: describe Base/Cats/Tom

# Base/Cats/Shmil
<-- TODO: describe Base/Cats/Shmil

# Base/Cats/Mitzi
<-- TODO: describe Base/Cats/Mitzi

# Base/Rice
<-- TODO: describe Base/Rice

# Base/Rice/White
<-- TODO: describe Base/Rice/White

# Base/Rice/Full
<-- TODO: describe Base/Rice/Full
